/*                                             W3C Reference Library libwww PLAIN TEXT STREAM
                                    PLAIN TEXT OBJECT
                                             
 */
/*
**      (c) COPYRIGHT MIT 1995.
**      Please first read the full copyright statement in the file COPYRIGH.
*/
/*

   This module is implemented by HTPlain.c, and it is a part of the W3C Reference Library.
   
 */
#ifndef HTPLAIN_H
#define HTPLAIN_H

#include "HTFormat.h"

extern HTConverter HTPlainPresent;

#endif
/*

   
   ___________________________________
   
                           @(#) $Id: HTPlain.h,v 1.1.1.1 1996/10/15 13:08:40 cvs Exp $
                                                                                          
    */
