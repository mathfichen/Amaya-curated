/*
 * Exports the registering function for the Extra Java/Thotlib API.
 */

#ifndef __CEXTRACT__
#ifdef __STDC__

extern void register_thotlib_Extra_stubs ( void );

#else /* __STDC__ */

extern void register_thotlib_Extra_stubs (/* void */);

#endif /* __STDC__ */
#endif /* __CEXTRACT__ */
