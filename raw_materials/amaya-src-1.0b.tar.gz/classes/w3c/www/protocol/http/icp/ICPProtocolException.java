// ICPProtocolException.java
// $Id: ICPProtocolException.java,v 1.2 1997/03/27 13:57:52 cvs Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// please first read the full copyright statement in file COPYRIGHT.HTML

package w3c.www.protocol.http.icp;

class ICPProtocolException extends Exception {

    ICPProtocolException(String msg) {
	super(msg);
    }

}
