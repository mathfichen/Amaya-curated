/*
 * HTTPInterf : This class is the front-end of the Java HTTP stack
 *              called by the Amaya program when remote accesses are
 *              needed.
 */
package amaya;

import amaya.*;

public class HTTPInterf {

       
}
