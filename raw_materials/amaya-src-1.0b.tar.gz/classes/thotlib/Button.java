package thotlib;

/*
 * Stub classes to interface the Thotlib button functions from Java
 */


public class Button {
	
}

