package thotlib;

/*
 * Stub classes to interface the Thotlib Language accesses from Java
 */


public class Language {
    char lang;
}

