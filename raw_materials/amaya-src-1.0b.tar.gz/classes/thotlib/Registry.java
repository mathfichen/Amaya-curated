package thotlib;

/*
 * Stub classes to interface the Thotlib Registry accesses from Java
 */


public class Registry {
}

