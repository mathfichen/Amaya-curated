/* Configuration for GCC for Intel i386 running FreeBSD as host.  */

#include <i386/xm-i386.h>
#include <xm-freebsd.h>
